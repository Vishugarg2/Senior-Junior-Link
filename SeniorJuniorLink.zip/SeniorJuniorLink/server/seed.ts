import { db } from "./db";
import { profiles } from "@shared/schema";

const sampleProfiles = [
  {
    name: "Sarah Chen",
    title: "Senior Product Manager",
    bio: "Passionate about building user-centric products. I love mentoring junior PMs and sharing insights on product strategy.",
    email: "sarah.chen@example.com",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=150&h=150",
    level: "senior",
    industry: "technology",
    skills: ["Product Strategy", "User Research", "Leadership"],
    experience: "8 years exp."
  },
  {
    name: "Michael Rodriguez",
    title: "Senior Software Engineer",
    bio: "Full-stack developer with expertise in React and Node.js. Happy to mentor junior developers on best practices.",
    email: "michael.rodriguez@example.com",
    avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=150&h=150",
    level: "senior",
    industry: "technology",
    skills: ["React", "Node.js", "Architecture"],
    experience: "12 years exp."
  },
  {
    name: "Emily Johnson",
    title: "Marketing Director",
    bio: "Digital marketing strategist with a track record of growing brands. Love helping junior marketers develop their skills.",
    email: "emily.johnson@example.com",
    avatar: "https://images.unsplash.com/photo-1494790108755-2616b612b5bc?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=150&h=150",
    level: "senior",
    industry: "marketing",
    skills: ["Digital Strategy", "Brand Growth", "Analytics"],
    experience: "10 years exp."
  },
  {
    name: "Alex Thompson",
    title: "Junior Frontend Developer",
    bio: "Recent computer science graduate passionate about creating beautiful, responsive web applications. Looking for mentorship opportunities.",
    email: "alex.thompson@example.com",
    avatar: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=150&h=150",
    level: "junior",
    industry: "technology",
    skills: ["JavaScript", "React", "CSS"],
    experience: "2 years exp."
  },
  {
    name: "David Park",
    title: "Junior Marketing Analyst",
    bio: "Data-driven marketing professional with strong analytical skills. Seeking guidance from experienced marketers to advance my career.",
    email: "david.park@example.com",
    avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=150&h=150",
    level: "junior",
    industry: "marketing",
    skills: ["Google Analytics", "Social Media", "Data Analysis"],
    experience: "1 year exp."
  },
  {
    name: "Maya Patel",
    title: "Junior UX Designer",
    bio: "Creative designer with a passion for user-centered design. Looking to learn from senior designers and improve my design process.",
    email: "maya.patel@example.com",
    avatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=150&h=150",
    level: "junior",
    industry: "design",
    skills: ["Figma", "User Research", "Prototyping"],
    experience: "1.5 years exp."
  }
];

export async function seedDatabase() {
  try {
    // Check if data already exists
    const existingProfiles = await db.select().from(profiles).limit(1);
    
    if (existingProfiles.length > 0) {
      console.log("Database already seeded, skipping...");
      return;
    }

    // Insert sample profiles
    await db.insert(profiles).values(sampleProfiles);
    console.log("Database seeded successfully with sample profiles");
  } catch (error) {
    console.error("Error seeding database:", error);
  }
}