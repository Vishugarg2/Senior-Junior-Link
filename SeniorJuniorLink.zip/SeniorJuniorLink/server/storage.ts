import { users, profiles, connections, type User, type InsertUser, type Profile, type InsertProfile, type Connection, type InsertConnection } from "@shared/schema";
import { db } from "./db";
import { eq, and, or, ilike } from "drizzle-orm";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Profile methods
  getProfile(id: number): Promise<Profile | undefined>;
  createProfile(profile: InsertProfile): Promise<Profile>;
  updateProfile(id: number, profile: Partial<InsertProfile>): Promise<Profile | undefined>;
  getAllProfiles(): Promise<Profile[]>;
  getProfilesByLevel(level: 'senior' | 'junior'): Promise<Profile[]>;
  searchProfiles(query: string, industry?: string, level?: string): Promise<Profile[]>;
  
  // Connection methods
  createConnection(connection: InsertConnection): Promise<Connection>;
  getConnectionsForProfile(profileId: number): Promise<Connection[]>;
  updateConnectionStatus(id: number, status: string): Promise<Connection | undefined>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async getProfile(id: number): Promise<Profile | undefined> {
    const [profile] = await db.select().from(profiles).where(eq(profiles.id, id));
    return profile || undefined;
  }

  async createProfile(profile: InsertProfile): Promise<Profile> {
    const [newProfile] = await db
      .insert(profiles)
      .values(profile)
      .returning();
    return newProfile;
  }

  async updateProfile(id: number, profileData: Partial<InsertProfile>): Promise<Profile | undefined> {
    const [updated] = await db
      .update(profiles)
      .set(profileData)
      .where(eq(profiles.id, id))
      .returning();
    return updated || undefined;
  }

  async getAllProfiles(): Promise<Profile[]> {
    return await db.select().from(profiles);
  }

  async getProfilesByLevel(level: 'senior' | 'junior'): Promise<Profile[]> {
    return await db.select().from(profiles).where(eq(profiles.level, level));
  }

  async searchProfiles(query: string, industry?: string, level?: string): Promise<Profile[]> {
    const conditions = [];
    
    if (query) {
      conditions.push(
        or(
          ilike(profiles.name, `%${query}%`),
          ilike(profiles.title, `%${query}%`),
          ilike(profiles.bio, `%${query}%`)
        )
      );
    }
    
    if (industry) {
      conditions.push(eq(profiles.industry, industry));
    }
    
    if (level) {
      conditions.push(eq(profiles.level, level));
    }
    
    if (conditions.length === 0) {
      return await db.select().from(profiles);
    }
    
    return await db.select().from(profiles).where(and(...conditions));
  }

  async createConnection(connection: InsertConnection): Promise<Connection> {
    const [newConnection] = await db
      .insert(connections)
      .values(connection)
      .returning();
    return newConnection;
  }

  async getConnectionsForProfile(profileId: number): Promise<Connection[]> {
    return await db
      .select()
      .from(connections)
      .where(
        or(
          eq(connections.fromProfileId, profileId),
          eq(connections.toProfileId, profileId)
        )
      );
  }

  async updateConnectionStatus(id: number, status: string): Promise<Connection | undefined> {
    const [updated] = await db
      .update(connections)
      .set({ status })
      .where(eq(connections.id, id))
      .returning();
    return updated || undefined;
  }
}

export const storage = new DatabaseStorage();
