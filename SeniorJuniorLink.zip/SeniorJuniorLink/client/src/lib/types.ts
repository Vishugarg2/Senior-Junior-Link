export interface SearchFilters {
  query: string;
  industry: string;
  level: string;
}

export interface ProfileFormData {
  name: string;
  title: string;
  bio: string;
  email: string;
  level: 'senior' | 'junior';
  industry: string;
  skills: string;
  experience: string;
}
