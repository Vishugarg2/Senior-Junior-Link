import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Profile } from "@shared/schema";
import Header from "@/components/header";
import SearchFilterBar from "@/components/search-filter-bar";
import ProfileCard from "@/components/profile-card";
import ProfileModal from "@/components/profile-modal";
import { SearchFilters } from "@/lib/types";

interface ProfilesProps {
  level?: 'senior' | 'junior';
}

export default function Profiles({ level }: ProfilesProps) {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [filters, setFilters] = useState<SearchFilters>({
    query: "",
    industry: "",
    level: level || "",
  });

  const { data: profiles = [], isLoading } = useQuery<Profile[]>({
    queryKey: ["/api/profiles", { 
      search: filters.query, 
      industry: filters.industry, 
      level: filters.level 
    }],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (filters.query) params.append('search', filters.query);
      if (filters.industry && filters.industry !== "all") params.append('industry', filters.industry);
      if (filters.level && filters.level !== "all") params.append('level', filters.level);
      
      const response = await fetch(`/api/profiles?${params.toString()}`, {
        credentials: 'include',
      });
      
      if (!response.ok) {
        throw new Error('Failed to fetch profiles');
      }
      
      return response.json();
    },
  });

  const handleFiltersChange = (newFilters: SearchFilters) => {
    setFilters(newFilters);
  };

  const handleApplyFilters = () => {
    // The query will automatically refetch when filters change
  };

  const getTitle = () => {
    if (level === 'senior') return 'Senior Professionals';
    if (level === 'junior') return 'Junior Professionals';
    return 'All Professionals';
  };

  const getDescription = () => {
    if (level === 'senior') return 'Connect with experienced mentors ready to share their knowledge and guide your career journey.';
    if (level === 'junior') return 'Discover talented emerging professionals eager to learn and contribute to your organization.';
    return 'Browse through our community of professionals looking to connect and grow together.';
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header onCreateProfile={() => setIsModalOpen(true)} />
      <SearchFilterBar 
        filters={filters}
        onFiltersChange={handleFiltersChange}
        onApplyFilters={handleApplyFilters}
      />

      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">{getTitle()}</h1>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              {getDescription()}
            </p>
          </div>
          
          {isLoading ? (
            <div className="text-center">
              <div className="inline-block animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
              <p className="mt-4 text-gray-600">Loading profiles...</p>
            </div>
          ) : profiles.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-gray-600 text-lg">No profiles found matching your criteria.</p>
              <p className="text-gray-500 mt-2">Try adjusting your search filters.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {profiles.map((profile) => (
                <ProfileCard key={profile.id} profile={profile} />
              ))}
            </div>
          )}
        </div>
      </section>

      <ProfileModal 
        isOpen={isModalOpen} 
        onClose={() => setIsModalOpen(false)} 
      />
    </div>
  );
}
