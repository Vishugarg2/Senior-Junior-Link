import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Profile } from "@shared/schema";
import Header from "@/components/header";
import HeroSection from "@/components/hero-section";
import SearchFilterBar from "@/components/search-filter-bar";
import ProfileCard from "@/components/profile-card";
import ProfileModal from "@/components/profile-modal";
import HowItWorks from "@/components/how-it-works";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { SearchFilters } from "@/lib/types";

export default function Home() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [filters, setFilters] = useState<SearchFilters>({
    query: "",
    industry: "",
    level: "",
  });

  const { data: seniorProfiles = [], isLoading: seniorLoading } = useQuery<Profile[]>({
    queryKey: ["/api/profiles/level/senior"],
  });

  const { data: juniorProfiles = [], isLoading: juniorLoading } = useQuery<Profile[]>({
    queryKey: ["/api/profiles/level/junior"],
  });

  const handleFiltersChange = (newFilters: SearchFilters) => {
    setFilters(newFilters);
  };

  const handleApplyFilters = () => {
    // This would typically trigger a new search
    console.log("Applying filters:", filters);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header onCreateProfile={() => setIsModalOpen(true)} />
      <HeroSection onCreateProfile={() => setIsModalOpen(true)} />
      <SearchFilterBar 
        filters={filters}
        onFiltersChange={handleFiltersChange}
        onApplyFilters={handleApplyFilters}
      />

      {/* Senior Professionals Section */}
      <section id="seniors" className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Senior Professionals</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Connect with experienced mentors ready to share their knowledge and guide your career journey.
            </p>
          </div>
          
          {seniorLoading ? (
            <div className="text-center">Loading...</div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {seniorProfiles.slice(0, 3).map((profile) => (
                <ProfileCard key={profile.id} profile={profile} />
              ))}
            </div>
          )}

          <div className="text-center mt-12">
            <Link href="/seniors">
              <Button variant="outline" size="lg">
                View All Senior Professionals
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Junior Professionals Section */}
      <section id="juniors" className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Junior Professionals</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Discover talented emerging professionals eager to learn and contribute to your organization.
            </p>
          </div>
          
          {juniorLoading ? (
            <div className="text-center">Loading...</div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {juniorProfiles.slice(0, 3).map((profile) => (
                <ProfileCard key={profile.id} profile={profile} />
              ))}
            </div>
          )}

          <div className="text-center mt-12">
            <Link href="/juniors">
              <Button size="lg" className="bg-accent hover:bg-green-600">
                View All Junior Professionals
              </Button>
            </Link>
          </div>
        </div>
      </section>

      <HowItWorks />

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-2xl font-bold mb-4">ConnectPro</h3>
              <p className="text-gray-400">
                Building bridges between senior professionals and emerging talent for meaningful career development.
              </p>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold mb-4">Platform</h4>
              <ul className="space-y-2 text-gray-400">
                <li><Link href="/profiles"><span className="hover:text-white transition-colors cursor-pointer">Browse Profiles</span></Link></li>
                <li><button onClick={() => setIsModalOpen(true)} className="hover:text-white transition-colors">Create Profile</button></li>
                <li><a href="#" className="hover:text-white transition-colors">Success Stories</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Resources</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold mb-4">Support</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white transition-colors">Help Center</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Safety Guidelines</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Contact Us</a></li>
                <li><a href="#" className="hover:text-white transition-colors">FAQ</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold mb-4">Connect</h4>
              <div className="flex space-x-4 text-gray-400">
                <a href="#" className="hover:text-white transition-colors">LinkedIn</a>
                <a href="#" className="hover:text-white transition-colors">Twitter</a>
                <a href="#" className="hover:text-white transition-colors">Facebook</a>
              </div>
            </div>
          </div>
          
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 ConnectPro. All rights reserved.</p>
          </div>
        </div>
      </footer>

      <ProfileModal 
        isOpen={isModalOpen} 
        onClose={() => setIsModalOpen(false)} 
      />
    </div>
  );
}
