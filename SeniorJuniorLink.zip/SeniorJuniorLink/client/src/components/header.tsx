import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Search, Mail, QrCode, Scan } from "lucide-react";
import QRScanner from "@/components/qr-scanner";

interface HeaderProps {
  onCreateProfile: () => void;
}

export default function Header({ onCreateProfile }: HeaderProps) {
  const [location] = useLocation();
  const [isScannerOpen, setIsScannerOpen] = useState(false);

  return (
    <header className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <Link href="/">
                <h1 className="text-2xl font-bold text-primary cursor-pointer">ConnectPro</h1>
              </Link>
            </div>
            <nav className="hidden md:ml-10 md:flex md:space-x-8">
              <Link href="/">
                <span className={`px-3 py-2 text-sm font-medium transition-colors cursor-pointer ${
                  location === "/" ? "text-primary" : "text-gray-600 hover:text-primary"
                }`}>
                  Home
                </span>
              </Link>
              <Link href="/seniors">
                <span className={`px-3 py-2 text-sm font-medium transition-colors cursor-pointer ${
                  location === "/seniors" ? "text-primary" : "text-gray-600 hover:text-primary"
                }`}>
                  Senior Professionals
                </span>
              </Link>
              <Link href="/juniors">
                <span className={`px-3 py-2 text-sm font-medium transition-colors cursor-pointer ${
                  location === "/juniors" ? "text-primary" : "text-gray-600 hover:text-primary"
                }`}>
                  Junior Professionals
                </span>
              </Link>
            </nav>
          </div>
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="sm">
              <Search className="h-5 w-5" />
            </Button>
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => setIsScannerOpen(true)}
              title="Scan QR Code"
            >
              <Scan className="h-5 w-5" />
            </Button>
            <Button variant="ghost" size="sm">
              <Mail className="h-5 w-5" />
            </Button>
            <Button onClick={onCreateProfile}>
              Join Network
            </Button>
          </div>
        </div>
      </div>
      
      <QRScanner 
        isOpen={isScannerOpen}
        onClose={() => setIsScannerOpen(false)}
      />
    </header>
  );
}
