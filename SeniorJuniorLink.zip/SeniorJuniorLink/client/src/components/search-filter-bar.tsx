import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Search } from "lucide-react";
import { SearchFilters } from "@/lib/types";

interface SearchFilterBarProps {
  filters: SearchFilters;
  onFiltersChange: (filters: SearchFilters) => void;
  onApplyFilters: () => void;
}

export default function SearchFilterBar({ 
  filters, 
  onFiltersChange, 
  onApplyFilters 
}: SearchFilterBarProps) {
  return (
    <section className="bg-white py-8 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col lg:flex-row gap-4 items-center">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              type="text"
              placeholder="Search by skills, industry, or name..."
              className="pl-10"
              value={filters.query}
              onChange={(e) => onFiltersChange({ ...filters, query: e.target.value })}
            />
          </div>
          <div className="flex flex-wrap gap-3">
            <Select 
              value={filters.industry || "all"} 
              onValueChange={(value) => onFiltersChange({ ...filters, industry: value === "all" ? "" : value })}
            >
              <SelectTrigger className="w-40">
                <SelectValue placeholder="All Industries" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Industries</SelectItem>
                <SelectItem value="technology">Technology</SelectItem>
                <SelectItem value="finance">Finance</SelectItem>
                <SelectItem value="healthcare">Healthcare</SelectItem>
                <SelectItem value="marketing">Marketing</SelectItem>
                <SelectItem value="design">Design</SelectItem>
              </SelectContent>
            </Select>
            <Select 
              value={filters.level || "all"} 
              onValueChange={(value) => onFiltersChange({ ...filters, level: value === "all" ? "" : value })}
            >
              <SelectTrigger className="w-40">
                <SelectValue placeholder="All Levels" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Levels</SelectItem>
                <SelectItem value="senior">Senior (5+ years)</SelectItem>
                <SelectItem value="junior">Junior (0-5 years)</SelectItem>
              </SelectContent>
            </Select>
            <Button onClick={onApplyFilters}>
              Apply Filters
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}
