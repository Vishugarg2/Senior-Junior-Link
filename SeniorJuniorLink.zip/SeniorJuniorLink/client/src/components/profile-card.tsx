import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Profile } from "@shared/schema";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { QrCode } from "lucide-react";
import { Link } from "wouter";
import QRGenerator from "@/components/qr-generator";

interface ProfileCardProps {
  profile: Profile;
}

export default function ProfileCard({ profile }: ProfileCardProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isQROpen, setIsQROpen] = useState(false);

  const connectMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest("POST", "/api/connections", {
        fromProfileId: 1, // This would be the current user's profile ID
        toProfileId: profile.id,
        message: "I'd like to connect with you for mentorship opportunities.",
      });
    },
    onSuccess: () => {
      toast({
        title: "Connection Request Sent",
        description: `Your connection request has been sent to ${profile.name}.`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/connections"] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to send connection request. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleConnect = () => {
    connectMutation.mutate();
  };

  return (
    <Card className="hover-lift hover:shadow-lg transition-all duration-200">
      <CardContent className="p-6">
        <div className="flex items-center mb-4">
          <img
            src={profile.avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${profile.name}`}
            alt={`${profile.name} profile`}
            className="w-16 h-16 rounded-full object-cover"
          />
          <div className="ml-4 flex-1">
            <h3 className="text-lg font-semibold text-gray-900">{profile.name}</h3>
            <p className="text-sm text-gray-600">{profile.title}</p>
            <div className="flex items-center mt-1">
              <Badge variant={profile.level === 'senior' ? 'default' : 'secondary'}>
                {profile.level === 'senior' ? 'Senior' : 'Junior'}
              </Badge>
              <span className="ml-2 text-xs text-gray-500">{profile.experience}</span>
            </div>
          </div>
        </div>
        <p className="text-gray-600 text-sm mb-4 line-clamp-3">{profile.bio}</p>
        <div className="flex flex-wrap gap-2 mb-4">
          {profile.skills.slice(0, 3).map((skill, index) => (
            <Badge key={index} variant="outline" className="text-xs">
              {skill}
            </Badge>
          ))}
        </div>
        <div className="flex space-x-2">
          <Button 
            className="flex-1" 
            onClick={handleConnect}
            disabled={connectMutation.isPending}
          >
            {connectMutation.isPending ? "Connecting..." : "Connect"}
          </Button>
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => setIsQROpen(true)}
            title="Generate QR Code"
          >
            <QrCode className="h-4 w-4" />
          </Button>
          <Link href={`/profiles/${profile.id}`}>
            <Button variant="outline" size="sm">
              View Profile
            </Button>
          </Link>
        </div>
        
        <QRGenerator 
          isOpen={isQROpen}
          onClose={() => setIsQROpen(false)}
          profile={profile}
        />
      </CardContent>
    </Card>
  );
}
