import { Button } from "@/components/ui/button";
import { Link } from "wouter";

interface HeroSectionProps {
  onCreateProfile: () => void;
}

export default function HeroSection({ onCreateProfile }: HeroSectionProps) {
  return (
    <section className="gradient-hero text-white py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h1 className="text-4xl md:text-6xl font-bold mb-6">
          Connect. Learn. Grow.
        </h1>
        <p className="text-xl md:text-2xl mb-8 text-blue-100 max-w-3xl mx-auto">
          Bridge the gap between experienced professionals and emerging talent. 
          Build meaningful mentorship connections that drive career success.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
          <Link href="/profiles">
            <Button variant="secondary" size="lg" className="text-primary">
              Browse Profiles
            </Button>
          </Link>
          <Button 
            variant="outline" 
            size="lg" 
            onClick={onCreateProfile}
            className="border-white text-white hover:bg-white hover:text-primary"
          >
            Create Profile
          </Button>
        </div>
      </div>
    </section>
  );
}
