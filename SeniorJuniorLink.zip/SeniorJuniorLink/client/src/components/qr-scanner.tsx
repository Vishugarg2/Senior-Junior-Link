import { useState, useRef, useEffect } from "react";
import { Html5QrcodeScanner } from "html5-qrcode";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { QrCode, Camera, X } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Profile } from "@shared/schema";
import { useQuery } from "@tanstack/react-query";

interface QRScannerProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function QRScanner({ isOpen, onClose }: QRScannerProps) {
  const [scannedData, setScannedData] = useState<string | null>(null);
  const [isScanning, setIsScanning] = useState(false);
  const [profile, setProfile] = useState<Profile | null>(null);
  const scannerRef = useRef<Html5QrcodeScanner | null>(null);
  const { toast } = useToast();

  const { data: profileData } = useQuery<Profile>({
    queryKey: ["/api/profiles", scannedData],
    queryFn: async () => {
      if (!scannedData) return null;
      try {
        const profileId = parseInt(scannedData);
        if (isNaN(profileId)) throw new Error("Invalid profile ID");
        
        const response = await fetch(`/api/profiles/${profileId}`);
        if (!response.ok) throw new Error("Profile not found");
        return response.json();
      } catch (error) {
        throw new Error("Failed to fetch profile");
      }
    },
    enabled: !!scannedData,
  });

  useEffect(() => {
    if (profileData) {
      setProfile(profileData);
    }
  }, [profileData]);

  const startScanner = () => {
    setIsScanning(true);
    setScannedData(null);
    setProfile(null);

    scannerRef.current = new Html5QrcodeScanner(
      "qr-reader",
      {
        fps: 10,
        qrbox: { width: 250, height: 250 },
        aspectRatio: 1.0,
        showTorchButtonIfSupported: true,
        showZoomSliderIfSupported: true,
      },
      false
    );

    scannerRef.current.render(
      (decodedText) => {
        setScannedData(decodedText);
        setIsScanning(false);
        scannerRef.current?.clear();
        toast({
          title: "QR Code Scanned",
          description: "Loading profile information...",
        });
      },
      (error) => {
        console.warn("QR scan error:", error);
      }
    );
  };

  const stopScanner = () => {
    if (scannerRef.current) {
      scannerRef.current.clear();
      scannerRef.current = null;
    }
    setIsScanning(false);
  };

  const handleClose = () => {
    stopScanner();
    setScannedData(null);
    setProfile(null);
    onClose();
  };

  useEffect(() => {
    return () => {
      stopScanner();
    };
  }, []);

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <QrCode className="h-5 w-5" />
            QR Code Scanner
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {!isScanning && !profile && (
            <div className="text-center space-y-4">
              <div className="bg-gray-100 rounded-lg p-8 flex flex-col items-center">
                <Camera className="h-12 w-12 text-gray-400 mb-4" />
                <p className="text-gray-600 mb-4">
                  Scan a profile QR code to instantly view professional details
                </p>
                <Button onClick={startScanner} className="flex items-center gap-2">
                  <Camera className="h-4 w-4" />
                  Start Scanning
                </Button>
              </div>
            </div>
          )}

          {isScanning && (
            <div className="space-y-4">
              <div id="qr-reader" className="border rounded-lg overflow-hidden"></div>
              <div className="flex gap-2">
                <Button 
                  variant="outline" 
                  onClick={stopScanner}
                  className="flex-1"
                >
                  <X className="h-4 w-4 mr-2" />
                  Stop Scanning
                </Button>
              </div>
            </div>
          )}

          {profile && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Scanned Profile</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-4">
                  <img
                    src={profile.avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${profile.name}`}
                    alt={`${profile.name} profile`}
                    className="w-16 h-16 rounded-full object-cover"
                  />
                  <div className="flex-1">
                    <h3 className="font-semibold text-lg">{profile.name}</h3>
                    <p className="text-gray-600">{profile.title}</p>
                    <div className="flex items-center gap-2 mt-1">
                      <Badge variant={profile.level === 'senior' ? 'default' : 'secondary'}>
                        {profile.level === 'senior' ? 'Senior' : 'Junior'}
                      </Badge>
                      <span className="text-sm text-gray-500">{profile.experience}</span>
                    </div>
                  </div>
                </div>

                <p className="text-gray-600 text-sm">{profile.bio}</p>

                <div className="space-y-2">
                  <h4 className="font-medium">Skills</h4>
                  <div className="flex flex-wrap gap-2">
                    {profile.skills.map((skill, index) => (
                      <Badge key={index} variant="outline" className="text-xs">
                        {skill}
                      </Badge>
                    ))}
                  </div>
                </div>

                <div className="space-y-2">
                  <h4 className="font-medium">Industry</h4>
                  <Badge variant="secondary">{profile.industry}</Badge>
                </div>

                <div className="flex gap-2 pt-4">
                  <Button className="flex-1">
                    Connect
                  </Button>
                  <Button variant="outline">
                    View Full Profile
                  </Button>
                </div>

                <Button 
                  variant="ghost" 
                  onClick={() => {
                    setProfile(null);
                    setScannedData(null);
                  }}
                  className="w-full"
                >
                  Scan Another Code
                </Button>
              </CardContent>
            </Card>
          )}

          {scannedData && !profile && (
            <div className="text-center p-4">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-2"></div>
              <p className="text-sm text-gray-600">Loading profile...</p>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}