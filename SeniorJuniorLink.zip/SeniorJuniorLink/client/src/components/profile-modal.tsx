import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { insertProfileSchema } from "@shared/schema";

const profileFormSchema = insertProfileSchema.extend({
  skills: z.string().min(1, "Skills are required"),
});

type ProfileFormData = z.infer<typeof profileFormSchema>;

interface ProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function ProfileModal({ isOpen, onClose }: ProfileModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<ProfileFormData>({
    resolver: zodResolver(profileFormSchema),
    defaultValues: {
      name: "",
      title: "",
      bio: "",
      email: "",
      level: "junior",
      industry: "",
      skills: "",
      experience: "",
      avatar: "",
    },
  });

  const mutation = useMutation({
    mutationFn: async (data: ProfileFormData) => {
      const skillsArray = data.skills.split(",").map(skill => skill.trim()).filter(Boolean);
      const profileData = {
        ...data,
        skills: skillsArray,
      };
      return await apiRequest("POST", "/api/profiles", profileData);
    },
    onSuccess: () => {
      toast({
        title: "Profile Created",
        description: "Your profile has been created successfully!",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/profiles"] });
      onClose();
      form.reset();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create profile. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: ProfileFormData) => {
    mutation.mutate(data);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Create Your Profile</DialogTitle>
        </DialogHeader>
        
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <Label htmlFor="name">Full Name</Label>
              <Input
                id="name"
                {...form.register("name")}
                className="mt-1"
              />
              {form.formState.errors.name && (
                <p className="text-sm text-red-500 mt-1">{form.formState.errors.name.message}</p>
              )}
            </div>
            <div>
              <Label htmlFor="title">Professional Title</Label>
              <Input
                id="title"
                {...form.register("title")}
                className="mt-1"
              />
              {form.formState.errors.title && (
                <p className="text-sm text-red-500 mt-1">{form.formState.errors.title.message}</p>
              )}
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <Label htmlFor="level">Experience Level</Label>
              <Select onValueChange={(value) => form.setValue("level", value as "senior" | "junior")}>
                <SelectTrigger className="mt-1">
                  <SelectValue placeholder="Select Level" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="junior">Junior (0-5 years)</SelectItem>
                  <SelectItem value="senior">Senior (5+ years)</SelectItem>
                </SelectContent>
              </Select>
              {form.formState.errors.level && (
                <p className="text-sm text-red-500 mt-1">{form.formState.errors.level.message}</p>
              )}
            </div>
            <div>
              <Label htmlFor="industry">Industry</Label>
              <Select onValueChange={(value) => form.setValue("industry", value)}>
                <SelectTrigger className="mt-1">
                  <SelectValue placeholder="Select Industry" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="technology">Technology</SelectItem>
                  <SelectItem value="finance">Finance</SelectItem>
                  <SelectItem value="healthcare">Healthcare</SelectItem>
                  <SelectItem value="marketing">Marketing</SelectItem>
                  <SelectItem value="design">Design</SelectItem>
                </SelectContent>
              </Select>
              {form.formState.errors.industry && (
                <p className="text-sm text-red-500 mt-1">{form.formState.errors.industry.message}</p>
              )}
            </div>
          </div>
          
          <div>
            <Label htmlFor="skills">Skills (comma-separated)</Label>
            <Input
              id="skills"
              {...form.register("skills")}
              placeholder="e.g., JavaScript, React, Node.js"
              className="mt-1"
            />
            {form.formState.errors.skills && (
              <p className="text-sm text-red-500 mt-1">{form.formState.errors.skills.message}</p>
            )}
          </div>
          
          <div>
            <Label htmlFor="experience">Years of Experience</Label>
            <Input
              id="experience"
              {...form.register("experience")}
              placeholder="e.g., 5 years exp."
              className="mt-1"
            />
            {form.formState.errors.experience && (
              <p className="text-sm text-red-500 mt-1">{form.formState.errors.experience.message}</p>
            )}
          </div>
          
          <div>
            <Label htmlFor="bio">Bio/Description</Label>
            <Textarea
              id="bio"
              {...form.register("bio")}
              rows={4}
              placeholder="Tell us about yourself and what you're looking for..."
              className="mt-1"
            />
            {form.formState.errors.bio && (
              <p className="text-sm text-red-500 mt-1">{form.formState.errors.bio.message}</p>
            )}
          </div>
          
          <div>
            <Label htmlFor="email">Contact Email</Label>
            <Input
              id="email"
              type="email"
              {...form.register("email")}
              className="mt-1"
            />
            {form.formState.errors.email && (
              <p className="text-sm text-red-500 mt-1">{form.formState.errors.email.message}</p>
            )}
          </div>
          
          <div className="flex space-x-4 pt-4">
            <Button 
              type="submit" 
              className="flex-1"
              disabled={mutation.isPending}
            >
              {mutation.isPending ? "Creating..." : "Create Profile"}
            </Button>
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
