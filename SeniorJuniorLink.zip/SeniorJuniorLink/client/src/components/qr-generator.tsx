import { useEffect, useRef } from "react";
import QRCode from "qrcode";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Download, Share2, QrCode } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Profile } from "@shared/schema";

interface QRGeneratorProps {
  isOpen: boolean;
  onClose: () => void;
  profile: Profile;
}

export default function QRGenerator({ isOpen, onClose, profile }: QRGeneratorProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const { toast } = useToast();

  useEffect(() => {
    if (isOpen && canvasRef.current && profile) {
      generateQRCode();
    }
  }, [isOpen, profile]);

  const generateQRCode = async () => {
    if (!canvasRef.current) return;

    try {
      const profileUrl = `${window.location.origin}/profiles/${profile.id}`;
      
      await QRCode.toCanvas(canvasRef.current, profile.id.toString(), {
        width: 256,
        margin: 2,
        color: {
          dark: '#1f2937',
          light: '#ffffff',
        },
        errorCorrectionLevel: 'M',
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to generate QR code",
        variant: "destructive",
      });
    }
  };

  const downloadQRCode = () => {
    if (!canvasRef.current) return;

    const link = document.createElement('a');
    link.download = `${profile.name.replace(/\s+/g, '_')}_QR_Code.png`;
    link.href = canvasRef.current.toDataURL();
    link.click();

    toast({
      title: "QR Code Downloaded",
      description: "Your profile QR code has been saved to downloads",
    });
  };

  const shareQRCode = async () => {
    if (!canvasRef.current) return;

    try {
      canvasRef.current.toBlob(async (blob) => {
        if (!blob) return;

        const file = new File([blob], `${profile.name}_QR_Code.png`, {
          type: 'image/png',
        });

        if (navigator.share && navigator.canShare({ files: [file] })) {
          await navigator.share({
            title: `${profile.name}'s Professional Profile`,
            text: `Connect with ${profile.name} on ConnectPro`,
            files: [file],
          });
        } else {
          // Fallback to copying the profile URL
          const profileUrl = `${window.location.origin}/profiles/${profile.id}`;
          await navigator.clipboard.writeText(profileUrl);
          toast({
            title: "Profile Link Copied",
            description: "Profile URL has been copied to clipboard",
          });
        }
      });
    } catch (error) {
      toast({
        title: "Share Failed",
        description: "Unable to share QR code",
        variant: "destructive",
      });
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <QrCode className="h-5 w-5" />
            Your Profile QR Code
          </DialogTitle>
        </DialogHeader>

        <Card>
          <CardHeader>
            <CardTitle className="text-center text-lg">{profile.name}</CardTitle>
            <p className="text-center text-gray-600">{profile.title}</p>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex justify-center">
              <div className="bg-white p-4 rounded-lg shadow-sm border">
                <canvas 
                  ref={canvasRef} 
                  className="block max-w-full h-auto"
                />
              </div>
            </div>

            <div className="text-center space-y-2">
              <p className="text-sm text-gray-600">
                Share this QR code to let others quickly access your professional profile
              </p>
              <p className="text-xs text-gray-500">
                Profile ID: {profile.id}
              </p>
            </div>

            <div className="flex gap-2">
              <Button 
                onClick={downloadQRCode} 
                variant="outline" 
                className="flex-1"
              >
                <Download className="h-4 w-4 mr-2" />
                Download
              </Button>
              <Button 
                onClick={shareQRCode} 
                className="flex-1"
              >
                <Share2 className="h-4 w-4 mr-2" />
                Share
              </Button>
            </div>

            <div className="bg-gray-50 p-4 rounded-lg">
              <h4 className="font-medium mb-2">How to use:</h4>
              <ul className="text-sm text-gray-600 space-y-1">
                <li>• Print and display at networking events</li>
                <li>• Add to business cards or email signatures</li>
                <li>• Share digitally on social media</li>
                <li>• Include in presentation slides</li>
              </ul>
            </div>
          </CardContent>
        </Card>
      </DialogContent>
    </Dialog>
  );
}